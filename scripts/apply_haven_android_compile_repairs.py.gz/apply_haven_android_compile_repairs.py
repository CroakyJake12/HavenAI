#!/usr/bin/env python3
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
changed = []

def edit(rel, transform):
    path = ROOT / rel
    old = path.read_text(encoding="utf-8")
    new = transform(old)
    if new != old:
        path.write_text(new, encoding="utf-8")
        changed.append(rel)

def one(text, old, new, label):
    if old in text:
        return text.replace(old, new, 1)
    if new in text:
        return text
    raise RuntimeError(f"{label}: anchor missing")

def model(text):
    text = text.replace("new LinearLayout.Layout.LayoutParams(", "new LinearLayout.LayoutParams(")
    text = one(text, '''        var button = new Button(this)
        {
            Text = label,
            AllCaps = false
        };
        button.SetTextColor(Color.White);''', '''        var button = new Button(this)
        {
            Text = label
        };
        button.SetAllCaps(false);
        button.SetTextColor(Color.White);''', "model action button")
    text = one(text, '''        var rootUri = DocumentsContract.BuildDocumentUriUsingTree(treeUri, rootDocumentId);
        return await ImportDocumentDirectoryAsync(treeUri, rootUri, depth: 0);''', '''        var rootUri = DocumentsContract.BuildDocumentUriUsingTree(treeUri, rootDocumentId);
        if (rootUri is null)
            return 0;
        return await ImportDocumentDirectoryAsync(treeUri, rootUri, depth: 0);''', "model root uri")
    text = one(text, '''        var childrenUri = DocumentsContract.BuildChildDocumentsUriUsingTree(treeUri, documentId);
        var imported = 0;''', '''        var childrenUri = DocumentsContract.BuildChildDocumentsUriUsingTree(treeUri, documentId);
        if (childrenUri is null)
            return 0;
        var imported = 0;''', "model children uri")
    text = one(text, '''            var childUri = DocumentsContract.BuildDocumentUriUsingTree(treeUri, childId);

            if (string.Equals(mimeType, DocumentsContract.Document.MimeTypeDir, StringComparison.Ordinal))''', '''            var childUri = DocumentsContract.BuildDocumentUriUsingTree(treeUri, childId);
            if (childUri is null)
                continue;

            if (string.Equals(mimeType, DocumentsContract.Document.MimeTypeDir, StringComparison.Ordinal))''', "model child uri")
    text = re.sub(r'(?<!System\.IO\.)\bPath\.', 'System.IO.Path.', text)
    text = text.replace("new FileStream(", "new System.IO.FileStream(")
    text = text.replace("FileMode.CreateNew", "System.IO.FileMode.CreateNew")
    text = text.replace("FileAccess.Write", "System.IO.FileAccess.Write")
    text = text.replace("FileShare.None", "System.IO.FileShare.None")
    text = text.replace("OpenableColumns.DisplayName", "IOpenableColumns.DisplayName")
    text = one(text, '''            var row = new LinearLayout(this)
            {
                Orientation = Orientation.Horizontal,
                Gravity = GravityFlags.CenterVertical
            };
            row.SetPadding(0, Dp(5), 0, Dp(5));''', '''            var row = new LinearLayout(this)
            {
                Orientation = Orientation.Horizontal
            };
            row.SetGravity(GravityFlags.CenterVertical);
            row.SetPadding(0, Dp(5), 0, Dp(5));''', "model list row")
    text = one(text, '''            var remove = new Button(this)
            {
                Text = "Remove",
                AllCaps = false
            };
            remove.Click += (_, _) =>''', '''            var remove = new Button(this)
            {
                Text = "Remove"
            };
            remove.SetAllCaps(false);
            remove.Click += (_, _) =>''', "model remove button")
    return text

def launcher(text):
    text = one(text, '''        var row = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal,
            Gravity = GravityFlags.CenterVertical,
            LayoutParameters = new LinearLayout.LayoutParams(''', '''        var row = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal,
            LayoutParameters = new LinearLayout.LayoutParams(''', "launcher row initializer")
    text = one(text, '''        };
        row.SetPadding(Dp(7), Dp(7), Dp(7), Dp(7));
        row.Background = MagicalBackground(Dp(28));''', '''        };
        row.SetGravity(GravityFlags.CenterVertical);
        row.SetPadding(Dp(7), Dp(7), Dp(7), Dp(7));
        row.Background = MagicalBackground(Dp(28));''', "launcher row setter")
    text = text.replace('''IconButton(
            Android.Resource.Drawable.IcMenuManage,''', '''GlyphButton(
            "◈",''')
    text = text.replace('''IconButton(
            Android.Resource.Drawable.IcMenuPreferences,''', '''GlyphButton(
            "⚙",''')
    text = text.replace('''IconButton(
            Android.Resource.Drawable.IcMenuSend,''', '''GlyphButton(
            "➤",''')
    text = one(text, '''        var go = new EditText(this)
        {
            Hint = "Go — ask Haven",
            SingleLine = true,
            TextSize = 15,''', '''        var go = new EditText(this)
        {
            Hint = "Go — ask Haven",
            TextSize = 15,''', "launcher go field")
    text = one(text, '''        };
        go.SetTextColor(Color.White);''', '''        };
        go.SetSingleLine(true);
        go.SetTextColor(Color.White);''', "launcher go setter")
    old_method = '''    private ImageButton IconButton(int resource, string description, Action action)
    {
        var button = new ImageButton(this)
        {
            ContentDescription = description,
            LayoutParameters = new LinearLayout.LayoutParams(Dp(48), Dp(48))
            {
                LeftMargin = Dp(2),
                RightMargin = Dp(2)
            }
        };
        button.SetImageResource(resource);
        button.SetColorFilter(Color.White);
        button.SetBackgroundColor(Color.Transparent);
        button.Click += (_, _) => action();
        return button;
    }
'''
    new_method = '''    private Button GlyphButton(string glyph, string description, Action action)
    {
        var button = new Button(this)
        {
            Text = glyph,
            ContentDescription = description,
            TextSize = 20,
            LayoutParameters = new LinearLayout.LayoutParams(Dp(48), Dp(48))
            {
                LeftMargin = Dp(2),
                RightMargin = Dp(2)
            }
        };
        button.SetAllCaps(false);
        button.SetTextColor(Color.White);
        button.SetBackgroundColor(Color.Transparent);
        button.Click += (_, _) => action();
        return button;
    }
'''
    text = one(text, old_method, new_method, "launcher glyph button")
    return text

def apps(text):
    text = one(text, '''        var tile = new LinearLayout(this)
        {
            Orientation = Orientation.Vertical,
            Gravity = GravityFlags.Center,
            ContentDescription = $"{app.Label}, {app.PackageName}",''', '''        var tile = new LinearLayout(this)
        {
            Orientation = Orientation.Vertical,
            ContentDescription = $"{app.Label}, {app.PackageName}",''', "app tile gravity")
    text = one(text, '''        };
        tile.SetPadding(Dp(4), Dp(4), Dp(4), Dp(4));''', '''        };
        tile.SetGravity(GravityFlags.Center);
        tile.SetPadding(Dp(4), Dp(4), Dp(4), Dp(4));''', "app tile gravity setter")
    text = one(text, '''                Text = app.Label,
                Gravity = GravityFlags.Center,
                TextSize = 12,
                MaxLines = 1,
                Ellipsize = Android.Text.TextUtils.TruncateAt.End
            };
            label.SetTextColor(Color.White);''', '''                Text = app.Label,
                Gravity = GravityFlags.Center,
                TextSize = 12
            };
            label.SetMaxLines(1);
            label.Ellipsize = global::Android.Text.TextUtils.TruncateAt.End;
            label.SetTextColor(Color.White);''', "app label")
    text = one(text, '''                Text = app.PackageName,
                Gravity = GravityFlags.Center,
                TextSize = 8,
                MaxLines = 1,
                Ellipsize = Android.Text.TextUtils.TruncateAt.Middle
            };
            package.SetTextColor(Color.Argb(210, 230, 220, 255));''', '''                Text = app.PackageName,
                Gravity = GravityFlags.Center,
                TextSize = 8
            };
            package.SetMaxLines(1);
            package.Ellipsize = global::Android.Text.TextUtils.TruncateAt.Middle;
            package.SetTextColor(Color.Argb(210, 230, 220, 255));''', "package label")
    text = one(text, '''        var header = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal,
            Gravity = GravityFlags.CenterVertical
        };''', '''        var header = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal
        };
        header.SetGravity(GravityFlags.CenterVertical);''', "drawer header")
    text = text.replace('''IconButton(
            Android.Resource.Drawable.IcMenuPreferences,''', '''GlyphButton(
            "⚙",''')
    text = text.replace('''IconButton(
            Android.Resource.Drawable.IcMenuCloseClearCancel,''', '''GlyphButton(
            "×",''')
    return text

def settings(text):
    text = one(text, '''        new AlertDialog.Builder(this)
            .SetTitle("Haven Launcher")
            .SetView(container)
            .SetPositiveButton("Save", (_, _) =>
            {
                Preferences.Edit()?
                    .PutInt(RowsKey, rows.Value)?
                    .PutInt(ColumnsKey, columns.Value)?
                    .PutBoolean(LabelsKey, labels.Checked)?
                    .PutBoolean(PackagesKey, packages.Checked)?
                    .Apply();
                _page = 0;
                RenderPage();
            })
            .SetNeutralButton("Wallpaper", (_, _) => ChooseWallpaper())
            .SetNegativeButton("Widgets", (_, _) => ShowWidgetMenu())
            .Show();''', '''        var dialog = new AlertDialog.Builder(this);
        dialog.SetTitle("Haven Launcher");
        dialog.SetView(container);
        dialog.SetPositiveButton("Save", (_, _) =>
        {
            UpdatePreferences(editor =>
            {
                editor.PutInt(RowsKey, rows.Value);
                editor.PutInt(ColumnsKey, columns.Value);
                editor.PutBoolean(LabelsKey, labels.Checked);
                editor.PutBoolean(PackagesKey, packages.Checked);
            });
            _page = 0;
            RenderPage();
        });
        dialog.SetNeutralButton("Wallpaper", (_, _) => ChooseWallpaper());
        dialog.SetNegativeButton("Widgets", (_, _) => ShowWidgetMenu());
        dialog.Show();''', "settings dialog")
    text = one(text, '''        var row = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal,
            Gravity = GravityFlags.CenterVertical
        };''', '''        var row = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal
        };
        row.SetGravity(GravityFlags.CenterVertical);''', "settings row")
    text = one(text, '''        new AlertDialog.Builder(this)
            .SetTitle("Add widget")
            .SetItems(
                new[] { "Android widget", "Haven clock widget" },
                (_, args) =>
                {
                    if (args.Which == 0)
                        PickAndroidWidget();
                    else
                        AddHavenWidget();
                })
            .Show();''', '''        var dialog = new AlertDialog.Builder(this);
        dialog.SetTitle("Add widget");
        dialog.SetItems(
            new[] { "Android widget", "Haven clock widget" },
            (_, args) =>
            {
                if (args is null)
                    return;
                if (args.Which == 0)
                    PickAndroidWidget();
                else
                    AddHavenWidget();
            });
        dialog.Show();''', "widget menu")
    text = one(text, '''        Preferences.Edit()?.PutBoolean(HavenWidgetKey, true)?.Apply();
        RenderWidgets();''', '''        UpdatePreferences(editor => editor.PutBoolean(HavenWidgetKey, true));
        RenderWidgets();''', "add haven widget")
    text = one(text, '''                Preferences.Edit()?.PutBoolean(HavenWidgetKey, false)?.Apply();
                RenderWidgets();''', '''                UpdatePreferences(editor => editor.PutBoolean(HavenWidgetKey, false));
                RenderWidgets();''', "remove haven widget")
    text = one(text, '''            var hostView = _widgetHost.CreateView(this, widgetId, info);
            hostView.SetAppWidget(widgetId, info);''', '''            var hostView = _widgetHost.CreateView(this, widgetId, info);
            if (hostView is null)
                continue;
            hostView.SetAppWidget(widgetId, info);''', "hosted widget nullability")
    text = one(text, '''            hostView.LongClick += (_, args) =>
            {
                new AlertDialog.Builder(this)
                    .SetMessage("Remove this widget?")
                    .SetPositiveButton("Remove", (_, _) =>
                    {
                        DeleteWidgetId(widgetId);
                        RenderWidgets();
                    })
                    .SetNegativeButton("Cancel", (_, _) => { })
                    .Show();
                args.Handled = true;
            };''', '''            hostView.LongClick += (_, args) =>
            {
                var dialog = new AlertDialog.Builder(this);
                dialog.SetMessage("Remove this widget?");
                dialog.SetPositiveButton("Remove", (_, _) =>
                {
                    DeleteWidgetId(widgetId);
                    RenderWidgets();
                });
                dialog.SetNegativeButton("Cancel", (_, _) => { });
                dialog.Show();
                args.Handled = true;
            };''', "widget removal dialog")
    text = one(text, '''        Preferences.Edit()?
            .PutString(WidgetIdsKey, string.Join(',', ids.OrderBy(id => id)))?
            .Apply();''', '''        UpdatePreferences(editor =>
            editor.PutString(WidgetIdsKey, string.Join(',', ids.OrderBy(id => id))));''', "save widget ids")
    text = one(text, '''        Preferences.Edit()?
            .PutString(WidgetIdsKey, string.Join(',', ids.OrderBy(id => id)))?
            .Apply();

        try''', '''        UpdatePreferences(editor =>
            editor.PutString(WidgetIdsKey, string.Join(',', ids.OrderBy(id => id))));

        try''', "delete widget ids")
    helper = '''    private void UpdatePreferences(Action<ISharedPreferencesEditor> update)
    {
        var editor = Preferences.Edit();
        if (editor is null)
            return;
        update(editor);
        editor.Apply();
    }

'''
    marker = '    private void OpenHavenDashboard()\n'
    if helper not in text:
        if marker not in text:
            raise RuntimeError("preferences helper anchor missing")
        text = text.replace(marker, helper + marker, 1)
    return text

def layout(text):
    return text.replace("ScrollBarVisibility.", "global::Avalonia.Controls.Primitives.ScrollBarVisibility.")

edit("src/Haven.Android/ModelImportActivity.cs", model)
edit("src/Haven.Android/HavenLauncherActivity.cs", launcher)
edit("src/Haven.Android/HavenLauncherActivity.Apps.cs", apps)
edit("src/Haven.Android/HavenLauncherActivity.Settings.cs", settings)
edit("src/Haven.Android/MainView.Mobile.Layout.cs", layout)

print("Updated:" if changed else "Already applied:")
for rel in changed:
    print(rel)
