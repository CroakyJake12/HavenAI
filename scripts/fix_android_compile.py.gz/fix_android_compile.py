#!/usr/bin/env python3
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def edit(rel, transforms):
    path = ROOT / rel
    text = path.read_text(encoding="utf-8")
    original = text
    for old, new, expected in transforms:
        count = text.count(old)
        if count == 0 and new in text:
            continue
        if count != expected:
            raise RuntimeError(f"{rel}: expected {expected} occurrence(s), found {count}: {old[:100]!r}")
        text = text.replace(old, new)
    if text != original:
        path.write_text(text, encoding="utf-8", newline="\n")
        print(f"updated {rel}")
    else:
        print(f"unchanged {rel}")

edit("src/Haven.Android/MainView.Mobile.Layout.cs", [
    (
        "using Avalonia.Controls;\n",
        "using Avalonia.Controls;\nusing ScrollBarVisibility = Avalonia.Controls.Primitives.ScrollBarVisibility;\n",
        1,
    ),
])

edit("src/Haven.Android/ModelImportActivity.cs", [
    (
        "using Android.Graphics;\n",
        "using Color = Android.Graphics.Color;\nusing Typeface = Android.Graphics.Typeface;\nusing IOPath = System.IO.Path;\n",
        1,
    ),
    ("new LinearLayout.Layout.LayoutParams(", "new LinearLayout.LayoutParams(", 1),
    (
        '''        var button = new Button(this)
        {
            Text = label,
            AllCaps = false
        };
        button.SetTextColor(Color.White);''',
        '''        var button = new Button(this)
        {
            Text = label
        };
        button.SetAllCaps(false);
        button.SetTextColor(Color.White);''',
        1,
    ),
    (
        '''        var rootUri = DocumentsContract.BuildDocumentUriUsingTree(treeUri, rootDocumentId);
        return await ImportDocumentDirectoryAsync(treeUri, rootUri, depth: 0);''',
        '''        var rootUri = DocumentsContract.BuildDocumentUriUsingTree(treeUri, rootDocumentId);
        if (rootUri is null)
            return 0;

        return await ImportDocumentDirectoryAsync(treeUri, rootUri, depth: 0);''',
        1,
    ),
    (
        '''        var childrenUri = DocumentsContract.BuildChildDocumentsUriUsingTree(treeUri, documentId);
        var imported = 0;''',
        '''        var childrenUri = DocumentsContract.BuildChildDocumentsUriUsingTree(treeUri, documentId);
        if (childrenUri is null)
            return 0;

        var imported = 0;''',
        1,
    ),
    (
        '''            var childUri = DocumentsContract.BuildDocumentUriUsingTree(treeUri, childId);''',
        '''            var childUri = DocumentsContract.BuildDocumentUriUsingTree(treeUri, childId);
            if (childUri is null)
                continue;''',
        1,
    ),
    ("Path.", "IOPath.", 7),
    (
        "new FileStream(destinationPath, FileMode.CreateNew, FileAccess.Write, FileShare.None)",
        "new System.IO.FileStream(destinationPath, System.IO.FileMode.CreateNew, System.IO.FileAccess.Write, System.IO.FileShare.None)",
        1,
    ),
    ("OpenableColumns.DisplayName", "IOpenableColumns.DisplayName", 2),
    (
        '''            var row = new LinearLayout(this)
            {
                Orientation = Orientation.Horizontal,
                Gravity = GravityFlags.CenterVertical
            };
            row.SetPadding(0, Dp(5), 0, Dp(5));''',
        '''            var row = new LinearLayout(this)
            {
                Orientation = Orientation.Horizontal
            };
            row.SetGravity(GravityFlags.CenterVertical);
            row.SetPadding(0, Dp(5), 0, Dp(5));''',
        1,
    ),
    (
        '''            var remove = new Button(this)
            {
                Text = "Remove",
                AllCaps = false
            };
            remove.Click += (_, _) =>''',
        '''            var remove = new Button(this)
            {
                Text = "Remove"
            };
            remove.SetAllCaps(false);
            remove.Click += (_, _) =>''',
        1,
    ),
])

edit("src/Haven.Android/HavenLauncherActivity.cs", [
    (
        '''        var row = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal,
            Gravity = GravityFlags.CenterVertical,
            LayoutParameters = new LinearLayout.LayoutParams(''',
        '''        var row = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal,
            LayoutParameters = new LinearLayout.LayoutParams(''',
        1,
    ),
    (
        '''        row.SetPadding(Dp(7), Dp(7), Dp(7), Dp(7));''',
        '''        row.SetGravity(GravityFlags.CenterVertical);
        row.SetPadding(Dp(7), Dp(7), Dp(7), Dp(7));''',
        1,
    ),
    ("Android.Resource.Drawable.IcMenuManage", 'SystemDrawable("ic_menu_manage")', 1),
    ("Android.Resource.Drawable.IcMenuPreferences", 'SystemDrawable("ic_menu_preferences")', 1),
    ("Android.Resource.Drawable.IcMenuSend", 'SystemDrawable("ic_menu_send")', 1),
    (
        '''        var go = new EditText(this)
        {
            Hint = "Go — ask Haven",
            SingleLine = true,
            TextSize = 15,''',
        '''        var go = new EditText(this)
        {
            Hint = "Go — ask Haven",
            TextSize = 15,''',
        1,
    ),
    (
        '''        go.SetTextColor(Color.White);''',
        '''        go.SetSingleLine(true);
        go.SetTextColor(Color.White);''',
        1,
    ),
    (
        '''    private ImageButton IconButton(int resource, string description, Action action)
    {''',
        '''    private int SystemDrawable(string name)
        => Resources?.GetIdentifier(name, "drawable", "android") ?? 0;

    private ImageButton IconButton(int resource, string description, Action action)
    {''',
        1,
    ),
])

edit("src/Haven.Android/HavenLauncherActivity.Apps.cs", [
    (
        '''        var tile = new LinearLayout(this)
        {
            Orientation = Orientation.Vertical,
            Gravity = GravityFlags.Center,
            ContentDescription = $"{app.Label}, {app.PackageName}",''',
        '''        var tile = new LinearLayout(this)
        {
            Orientation = Orientation.Vertical,
            ContentDescription = $"{app.Label}, {app.PackageName}",''',
        1,
    ),
    (
        '''        tile.SetPadding(Dp(4), Dp(4), Dp(4), Dp(4));''',
        '''        tile.SetGravity(GravityFlags.Center);
        tile.SetPadding(Dp(4), Dp(4), Dp(4), Dp(4));''',
        1,
    ),
    (
        '''            var label = new TextView(this)
            {
                Text = app.Label,
                Gravity = GravityFlags.Center,
                TextSize = 12,
                MaxLines = 1,
                Ellipsize = Android.Text.TextUtils.TruncateAt.End
            };
            label.SetTextColor(Color.White);''',
        '''            var label = new TextView(this)
            {
                Text = app.Label,
                Gravity = GravityFlags.Center,
                TextSize = 12
            };
            label.SetMaxLines(1);
            label.Ellipsize = global::Android.Text.TextUtils.TruncateAt.End;
            label.SetTextColor(Color.White);''',
        1,
    ),
    (
        '''            var package = new TextView(this)
            {
                Text = app.PackageName,
                Gravity = GravityFlags.Center,
                TextSize = 8,
                MaxLines = 1,
                Ellipsize = Android.Text.TextUtils.TruncateAt.Middle
            };
            package.SetTextColor(Color.Argb(210, 230, 220, 255));''',
        '''            var package = new TextView(this)
            {
                Text = app.PackageName,
                Gravity = GravityFlags.Center,
                TextSize = 8
            };
            package.SetMaxLines(1);
            package.Ellipsize = global::Android.Text.TextUtils.TruncateAt.Middle;
            package.SetTextColor(Color.Argb(210, 230, 220, 255));''',
        1,
    ),
    (
        '''        var header = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal,
            Gravity = GravityFlags.CenterVertical
        };''',
        '''        var header = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal
        };
        header.SetGravity(GravityFlags.CenterVertical);''',
        1,
    ),
    ("Android.Resource.Drawable.IcMenuPreferences", 'SystemDrawable("ic_menu_preferences")', 1),
    ("Android.Resource.Drawable.IcMenuCloseClearCancel", 'SystemDrawable("ic_menu_close_clear_cancel")', 1),
])

edit("src/Haven.Android/HavenLauncherActivity.Settings.cs", [
    (
        '''        new AlertDialog.Builder(this)
            .SetTitle("Haven Launcher")
            .SetView(container)
            .SetPositiveButton("Save", (_, _) =>
            {
                Preferences.Edit()?
                    .PutInt(RowsKey, rows.Value)?
                    .PutInt(ColumnsKey, columns.Value)?
                    .PutBoolean(LabelsKey, labels.Checked)?
                    .PutBoolean(PackagesKey, packages.Checked)?
                    .Apply();
                _page = 0;
                RenderPage();
            })
            .SetNeutralButton("Wallpaper", (_, _) => ChooseWallpaper())
            .SetNegativeButton("Widgets", (_, _) => ShowWidgetMenu())
            .Show();''',
        '''        var dialog = new AlertDialog.Builder(this);
        dialog.SetTitle("Haven Launcher");
        dialog.SetView(container);
        dialog.SetPositiveButton("Save", (_, _) =>
        {
            var editor = Preferences.Edit();
            if (editor is not null)
            {
                editor.PutInt(RowsKey, rows.Value);
                editor.PutInt(ColumnsKey, columns.Value);
                editor.PutBoolean(LabelsKey, labels.Checked);
                editor.PutBoolean(PackagesKey, packages.Checked);
                editor.Apply();
            }

            _page = 0;
            RenderPage();
        });
        dialog.SetNeutralButton("Wallpaper", (_, _) => ChooseWallpaper());
        dialog.SetNegativeButton("Widgets", (_, _) => ShowWidgetMenu());
        dialog.Show();''',
        1,
    ),
    (
        '''        var row = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal,
            Gravity = GravityFlags.CenterVertical
        };''',
        '''        var row = new LinearLayout(this)
        {
            Orientation = Orientation.Horizontal
        };
        row.SetGravity(GravityFlags.CenterVertical);''',
        1,
    ),
    (
        '''        new AlertDialog.Builder(this)
            .SetTitle("Add widget")
            .SetItems(
                new[] { "Android widget", "Haven clock widget" },
                (_, args) =>
                {
                    if (args.Which == 0)
                        PickAndroidWidget();
                    else
                        AddHavenWidget();
                })
            .Show();''',
        '''        var dialog = new AlertDialog.Builder(this);
        dialog.SetTitle("Add widget");
        dialog.SetItems(
            new[] { "Android widget", "Haven clock widget" },
            (_, args) =>
            {
                if (args.Which == 0)
                    PickAndroidWidget();
                else
                    AddHavenWidget();
            });
        dialog.Show();''',
        1,
    ),
    (
        '''        if (_widgetStrip is null)
            return;

        _widgetStrip.RemoveAllViews();''',
        '''        var widgetStrip = _widgetStrip;
        if (widgetStrip is null)
            return;

        widgetStrip.RemoveAllViews();''',
        1,
    ),
    ("_widgetStrip.AddView(clock);", "widgetStrip.AddView(clock);", 1),
    (
        '''        if (_widgetHost is null || _widgetManager is null)
            return;

        foreach (var widgetId in ReadWidgetIds().ToArray())
        {
            var info = _widgetManager.GetAppWidgetInfo(widgetId);''',
        '''        var widgetHost = _widgetHost;
        var widgetManager = _widgetManager;
        if (widgetHost is null || widgetManager is null)
            return;

        foreach (var widgetId in ReadWidgetIds().ToArray())
        {
            var info = widgetManager.GetAppWidgetInfo(widgetId);''',
        1,
    ),
    ("var hostView = _widgetHost.CreateView(this, widgetId, info);", "var hostView = widgetHost.CreateView(this, widgetId, info);", 1),
    (
        '''                new AlertDialog.Builder(this)
                    .SetMessage("Remove this widget?")
                    .SetPositiveButton("Remove", (_, _) =>
                    {
                        DeleteWidgetId(widgetId);
                        RenderWidgets();
                    })
                    .SetNegativeButton("Cancel", (_, _) => { })
                    .Show();''',
        '''                var dialog = new AlertDialog.Builder(this);
                dialog.SetMessage("Remove this widget?");
                dialog.SetPositiveButton("Remove", (_, _) =>
                {
                    DeleteWidgetId(widgetId);
                    RenderWidgets();
                });
                dialog.SetNegativeButton("Cancel", (_, _) => { });
                dialog.Show();''',
        1,
    ),
    ("_widgetStrip.AddView(hostView);", "widgetStrip.AddView(hostView);", 1),
])
